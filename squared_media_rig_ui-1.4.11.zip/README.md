# Thank you for using the new SQM Pro Rig V1!

For Questions visit the [wiki](https://github.com/Squared-Media/squared-media-rig-ui/wiki/home) or our [discord](https://discord.gg/square)

🚧 under construction 🚧
