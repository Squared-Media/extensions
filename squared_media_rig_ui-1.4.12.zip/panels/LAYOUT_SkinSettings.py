from ..msc.utils import (
    NodeTree,
    get_material,
    get_material_object,
    get_node_group,
    is_packed,
    get_rig,
    Material,
)
from .. import properties
import bpy  # type: ignore

rigID = properties.RigProperties.rigID
category = properties.UIProperties.category


def eye_settings(self, context, Eye, ParentBox, name):
    ParentBox.label(text=name, icon="HIDE_OFF")
    row = ParentBox.column(align=True)

    row = ParentBox.row()
    row.prop(Eye[0], "default_value", text=Eye[0].name)

    row = ParentBox.row()
    row.prop(Eye[1], "default_value", text=Eye[1].name)

    row = ParentBox.row()
    row.prop(Eye[2], "default_value", text=Eye[2].name)

    row = ParentBox.row()
    row.prop(Eye[3], "default_value", text=Eye[3].name, toggle=True)

    row = ParentBox.row()
    row.prop(Eye[4], "default_value", text=Eye[4].name)


def draw_advanced_Eyes(self, context, Eye, ParentBox, name, eye_overrides):
    # Advanced Settings
    ParentBox.label(text=name, icon="HIDE_OFF")
    col = ParentBox.column()

    # Overrides
    override_box = col.box()
    override_box.prop(
        eye_overrides["EYEWHITE"].outputs[0], "default_value", text="Eyewhite"
    )
    override_box.prop(eye_overrides["RIM"].outputs[0], "default_value", text="Rim")

    Pupil = col.box()
    Pupil.label(text="Pupil")
    Pupil = Pupil.column(align=True)
    Pupil.prop(Eye[5], "default_value", text=Eye[5].name)
    Pupil.prop(Eye[6], "default_value", text=Eye[6].name)
    Pupil.prop(Eye[7], "default_value", text=Eye[7].name)
    Pupil.prop(Eye[8], "default_value", text=Eye[8].name)
    #
    Pupil.label(text="Iris")
    Pupil.prop(Eye[9], "default_value", text=Eye[9].name)
    Pupil.prop(Eye[12], "default_value", text=Eye[12].name)

    #
    #
    Reflection = col.box()
    Reflection.label(text="Reflection")
    Reflection = Reflection.column(align=True)
    #
    Reflection.prop(Eye[13], "default_value", text=Eye[13].name)
    Reflection.prop(Eye[14], "default_value", text=Eye[14].name)

    row = Reflection.row()
    row = row.split(factor=0.5)
    row.label(text="Rotation")
    row.prop(Eye[16], "default_value", text="")


def draw_eyebrowBox(self, context, Eyebrow, Parentbox, name):
    Parentbox.label(text=name)
    row = Parentbox.row()
    row.prop(Eyebrow[0], "default_value", text=Eyebrow[0].name)

    # row = Parentbox.row()
    # row.prop(Eyebrow[1], "default_value", text = Eyebrow[1].name)


def draw_TextureBox(self, context, layout, rig, Mat_obj):
    if Mat_obj is None:
        Errorbox = layout.box()
        Errorbox.label(text="ERROR: No material object found")
        return

    TexutureBox = layout.box()
    TexutureBox.prop(
        rig.pose.bones["WGT-UIProperties"],
        '["SkinConf"]',
        toggle=True,
        icon="DOWNARROW_HLT"
        if rig.pose.bones["WGT-UIProperties"]["SkinConf"]
        else "RIGHTARROW",
        emboss=False,
        text="Skin Selector",
    )
    if rig.pose.bones["WGT-UIProperties"]["SkinConf"]:
        # Material and Node tree are needed for the SSS slider
        material = get_material(rig, Material.SKIN)
        node_tree = material.node_tree.nodes

        # todo: eventually we need to rename these things to the characters name to avoid .001 clutter
        DataBone = rig.data.bones["Data_Obj"]
        node_tree_skin = DataBone["skin_shader_nodes"].nodes
        img = node_tree_skin["SkinTexture"].image

        left = TexutureBox.row(align=True)
        if img is None:
            left.template_ID(
                node_tree_skin["SkinTexture"],
                "image",
                open="image.open",
            )
            return

        left.operator("squaredmedia.imgpack", icon="PACKAGE").id_name = img.name

        main = left.row(align=True)
        main.enabled = not is_packed(img)
        main.prop(img, "filepath", text="")
        main.operator("squaredmedia.imgreload", icon="FILE_REFRESH").id_name = img.name

        TexutureBox.prop(rig.pose.bones["Skin_cfg"], '["Slim Arms"]', toggle=True)
        TexutureBox.prop(
            node_tree["SkinShader"].inputs[8],
            "default_value",
            text="Subsurface Scattering",
        )


def draw_proportionBox(self, context, layout, rig):
    # Proportions
    ProportionsBox = layout.box()
    ProportionsBox.prop(
        rig.pose.bones["WGT-UIProperties"],
        '["FaceConfig"]',
        toggle=True,
        icon="DOWNARROW_HLT"
        if rig.pose.bones["WGT-UIProperties"]["FaceConfig"]
        else "RIGHTARROW",
        emboss=False,
        text="Face Configurator  ",
    )

    if rig.pose.bones["WGT-UIProperties"]["FaceConfig"]:
        # General
        GenerablBox = ProportionsBox.box()
        GenerablBox.label(text="General")
        row = GenerablBox.row()
        row.prop(
            rig.pose.bones["Skin_cfg"],
            '["FaceHeight"]',
            toggle=True,
            text="Face Height",
        )

        # Eyebrows
        Eyebrowbox = ProportionsBox.box()
        Eyebrowbox.label(text="Eybrows")
        row = Eyebrowbox.row()
        row.prop(
            rig.pose.bones["Skin_cfg"],
            '["Eyebrow_R_enabled"]',
            text="Eyebrow R",
            toggle=True,
        )
        row.prop(
            rig.pose.bones["Skin_cfg"],
            '["Eyebrow_L_enabled"]',
            text="Eyebrow L",
            toggle=True,
        )
        row = Eyebrowbox.row()
        row.prop(
            rig.pose.bones["Skin_cfg"],
            '["EyebrowHeight"]',
            text="Eyebrow Height Offset",
            toggle=True,
        )
        row = Eyebrowbox.row()
        row.prop(
            rig.pose.bones["Skin_cfg"],
            '["Eyebrow_gap"]',
            toggle=True,
            text="Eyebrow Gap",
        )

        # Eyes
        Eyebox = ProportionsBox.box()
        Eyebox.label(text="Eyes")
        row = Eyebox.row()
        row.prop(
            rig.pose.bones["Skin_cfg"], '["Eye_R_enable"]', text="Eye R", toggle=True
        )
        row.prop(
            rig.pose.bones["Skin_cfg"], '["Eye_L_enable"]', text="Eye L", toggle=True
        )

        row = Eyebox.row()
        row.prop(
            rig.pose.bones["Skin_cfg"],
            '["Eye_R_Height"]',
            toggle=True,
            text="Eye R Height",
        )
        row.prop(
            rig.pose.bones["Skin_cfg"],
            '["Eye_L_Height"]',
            toggle=True,
            text="Eye L Height",
        )

        row = Eyebox.row()
        row.prop(
            rig.pose.bones["Skin_cfg"],
            '["EyeHeight"]',
            text="Eye Height Offset",
            toggle=True,
        )

        # Mouth
        Mouthbox = ProportionsBox.box()
        Mouthbox.label(text="Mouth")
        Mouthbox.prop(
            rig.pose.bones["Skin_cfg"], '["Mouth_enable"]', text="Mouth", toggle=True
        )

        if rig.pose.bones["Skin_cfg"]["Mouth_enable"]:
            Mouthbox.box().prop(
                rig.pose.bones["Skin_cfg"],
                '["Teeth_enable"]',
                text="Teeth",
                toggle=True,
            )
        row = Mouthbox.row()
        row.prop(
            rig.pose.bones["Skin_cfg"], '["MouthHeight"]', text="Mouth Height Offset"
        )

        AdvancedBox = ProportionsBox.box()
        AdvancedBox.prop(
            rig.pose.bones["WGT-UIProperties"],
            '["Advanced_Face_Config"]',
            toggle=True,
            icon="DOWNARROW_HLT"
            if rig.pose.bones["WGT-UIProperties"]["Advanced_Face_Config"]
            else "RIGHTARROW",
            emboss=False,
            text="Advanced Face Settings",
        )

        if rig.pose.bones["WGT-UIProperties"]["Advanced_Face_Config"]:
            AdvancedBox.label(text="Advanced")
            row = AdvancedBox.row()
            split = row.split(factor=0.5)
            col = split.column(align=True)
            col.prop(
                rig.pose.bones["Skin_cfg"],
                '["Eyebrow_R_Thickness"]',
                text="Eyebrow R Thickness",
            )
            col.prop(
                rig.pose.bones["Skin_cfg"],
                '["Eyebrow_R_Height"]',
                text="Eyebrow R Height",
            )
            col = split.column(align=True)
            col.prop(
                rig.pose.bones["Skin_cfg"],
                '["Eyebrow_L_Thickness"]',
                text="Eyebrow L Thickness",
            )
            col.prop(
                rig.pose.bones["Skin_cfg"],
                '["Eyebrow_L_Height"]',
                text="Eyebrow L Height",
            )
            row = AdvancedBox.row()
            col = row.column(align=True)
            col.prop(
                rig.pose.bones["Skin_cfg"],
                '["Eye_R_Width"]',
                toggle=True,
                text="Eye R Width",
            )
            col = row.column(align=True)
            col.prop(
                rig.pose.bones["Skin_cfg"],
                '["Eye_L_Width"]',
                toggle=True,
                text="Eye L Width",
            )
            AdvancedBox.prop(
                rig.pose.bones["Skin_cfg"], '["Eye_Gap"]', toggle=True, text="Eye Gap"
            )

            eye_gap = rig.pose.bones["Skin_cfg"]["Eye_Gap"]
            smooth_render = rig.pose.bones["Settings"]["subd_render"]
            smooth_viewport = rig.pose.bones["Settings"]["subd_viewport"]

            if (eye_gap > 3.27 or eye_gap < 0.2) and (smooth_render or smooth_viewport):
                warningBox = AdvancedBox.box()
                warningBox.alert = True
                warningBox.label(
                    text="Eye Gap is high, this can affect Head Smoothing Quality",
                    icon="ERROR",
                )


def draw_EyeBox(self, context, layout, rig, Mat_obj):
    # Eye Settings
    ColorBox = layout.box()
    ColorBox.prop(
        rig.pose.bones["WGT-UIProperties"],
        '["EyeConfig"]',
        toggle=True,
        icon="DOWNARROW_HLT"
        if rig.pose.bones["WGT-UIProperties"]["EyeConfig"]
        else "RIGHTARROW",
        emboss=False,
        text="Eye & Brow Settings",
    )
    if rig.pose.bones["WGT-UIProperties"]["EyeConfig"]:
        # Eyes
        EyeBox = ColorBox.row().box()
        EyeBox.label(text="Eye Settings")
        Eye = EyeBox.split(factor=0.5)
        EyeLBox = Eye.box()
        EyeRBox = Eye.box()
        # Right Eye
        if rig.pose.bones["Skin_cfg"]["Eye_R_enable"]:
            EyeR = Mat_obj.material_slots[1].material.node_tree.nodes["Eye.R"].inputs
            eye_settings(self, context, EyeR, EyeRBox, "Right")
        else:
            EyeRBox.label(text="disabled")

        # Left Eye
        if rig.pose.bones["Skin_cfg"]["Eye_L_enable"]:
            EyeL = Mat_obj.material_slots[2].material.node_tree.nodes["Eye.L"].inputs
            eye_settings(self, context, EyeL, EyeLBox, "Left")
        else:
            EyeLBox.label(text="disabled")
        # Eyebrows
        EyebrowBox = ColorBox.row().box()
        EyebrowBox.label(text="Eyebrow Settings")
        Eyebrow = EyebrowBox.split(factor=0.5)
        EyebrowLBox = Eyebrow.box()
        EyebrowRBox = Eyebrow.box()

        nodes = get_material(rig, Material.EYEBROW_L).node_tree.nodes.get("Eyebrow.L")
        print("##############################################")
        print(nodes)
        print("##############################################")

        EyebrowR = (
            get_material(rig, Material.EYEBROW_R).node_tree.nodes["Eyebrow.R"].inputs
        )
        EyebrowL = (
            get_material(rig, Material.EYEBROW_L).node_tree.nodes["Eyebrow.L"].inputs
        )
        if rig.pose.bones["Skin_cfg"]["Eyebrow_R_enabled"]:
            draw_eyebrowBox(self, context, EyebrowR, EyebrowRBox.box(), "Right")
        else:
            EyebrowRBox.label(text="disabled")

        if rig.pose.bones["Skin_cfg"]["Eyebrow_L_enabled"]:
            draw_eyebrowBox(self, context, EyebrowL, EyebrowLBox.box(), "Left")
        else:
            EyebrowLBox.label(text="disabled")


def draw_advanced_EyeBox(self, context, layout, rig, Mat_obj):
    # Eye Settings
    ColorBox = layout.box()
    ColorBox.prop(
        rig.pose.bones["WGT-UIProperties"],
        '["EyeRigConf"]',
        toggle=True,
        icon="DOWNARROW_HLT"
        if rig.pose.bones["WGT-UIProperties"]["EyeRigConf"]
        else "RIGHTARROW",
        emboss=False,
        text="Advanced Eye Settings",
    )
    if rig.pose.bones["WGT-UIProperties"]["EyeRigConf"]:
        Eye = ColorBox.row()

        if (
            rig.pose.bones["Skin_cfg"]["Eye_R_enable"]
            and rig.pose.bones["Skin_cfg"]["Eye_L_enable"]
        ):
            Eye = Eye.split(factor=0.5)

        EyeRBox = Eye.box()
        EyeLBox = Eye.box()

        # Right Eye
        if rig.pose.bones["Skin_cfg"]["Eye_R_enable"]:
            EyeR = get_material(rig, Material.EYE_R).node_tree.nodes["Eye.R"].inputs
            EyeWhiteShaderR = get_node_group(rig, NodeTree.EYEWHITE_R)
            print(EyeWhiteShaderR.nodes.get("EYEWHITE"))
            draw_advanced_Eyes(
                self, context, EyeR, EyeRBox, "Right", EyeWhiteShaderR.nodes
            )
        else:
            EyeRBox.label(text="disabled")

        # Left Eye
        if rig.pose.bones["Skin_cfg"]["Eye_L_enable"]:
            EyeL = get_material(rig, Material.EYE_L).node_tree.nodes["Eye.L"].inputs
            EyeWhiteShaderL = get_node_group(rig, NodeTree.EYEWHITE_L)
            draw_advanced_Eyes(
                self, context, EyeL, EyeLBox, "Left", EyeWhiteShaderL.nodes
            )
        else:
            EyeLBox.label(text="disabled")


def draw_export_import(self, context, layout):
    Row = layout.row()
    Row.operator("squaredmedia.loadconfig")
    Row.operator("squaredmedia.saveconfig")


def draw_skin_settings(self, context):
    rig = get_rig(context)
    Mat_obj = get_material_object(rig)
    layout = self.layout

    draw_TextureBox(self, context, layout, rig, Mat_obj)
    draw_proportionBox(self, context, layout, rig)
    draw_EyeBox(self, context, layout, rig, Mat_obj)
    draw_advanced_EyeBox(self, context, layout, rig, Mat_obj)
    draw_export_import(self, context, layout)
